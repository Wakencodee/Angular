export class BlogModel{
    id : number = 0;
    title : string ='';
    description : string ='';
    details : string ='';
}